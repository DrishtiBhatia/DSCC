import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

public class Client {
	public static void main(String args[]) throws IOException {
		Scanner sc = new Scanner(System.in);
		DatagramSocket ds = new DatagramSocket();
		InetAddress ip = InetAddress.getLocalHost();
		byte buf[] = null;
		byte buf2[] = null;
		while (true) {
			System.out.print("Enter the equation in the format:");
			String inp = sc.nextLine();
			buf = new byte[65535];
			buf = inp.getBytes();
			DatagramPacket DpSend = new DatagramPacket(buf, buf.length, ip, 1234);
			ds.send(DpSend);
			if (inp.equals("bye"))
				break;
			buf = new byte[65535];
			buf2 = new byte[65535];
			DatagramPacket DpReceive = new DatagramPacket(buf, buf.length);
			ds.receive(DpReceive);
			DatagramPacket DpReceive2 = new DatagramPacket(buf2, buf2.length);
			ds.receive(DpReceive2);
			System.out.println("Answer = " + new String(buf, 0, buf.length));
			System.out.println(new String(buf2, 0, buf2.length));
			
//			String result = new String(buf, 0, buf.length);
//			int result1= Integer.parseInt(result);
//			System.out.println(result1);
			
//			if(result1>250) {
//				System.out.println("The multiplication result is above 250");
//			}
//			else {
//				System.out.println("The multiplication result is not above 250");
//			}
			
			
		}
	}
}