import java.sql.*;
import java.util.*;

public class ImplExample implements EmployeeInterface {
	public List<Employee> getallemployees() throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		List<Employee> list = new ArrayList<Employee>();
		String DB_URL = "jdbc:mysql://127.0.0.1/companydb";
		Connection conn = null;
		Statement stmt = null;
		System.out.println("Connecting to a selected database...");
		conn = DriverManager.getConnection(DB_URL, "root", "");
		System.out.println("Connected database successfully...");
		System.out.println("Creating statement...");
		stmt = conn.createStatement();
		String sql = "SELECT * FROM employee";
		ResultSet rs = stmt.executeQuery(sql);
		while (rs.next()) {
			int id = rs.getInt("id");
			String name = rs.getString("name");
			String contact = rs.getString("contact");
			Employee employee = new Employee();
			employee.setId(id);
			employee.setName(name);
			employee.setContact(contact);
			list.add(employee);
		}
		rs.close();
		return list;
	}

	public Employee getcontactbyname(String name) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Employee employee = null;
		String DB_URL = "jdbc:mysql://127.0.0.1/companydb";
		Connection conn = null;
		System.out.println("Connecting to a selected database...");
		conn = DriverManager.getConnection(DB_URL, "root", "");
		System.out.println("Connected database successfully...");
		System.out.println("Creating statement...");
		String query = "Select * from employee where name=?";
		PreparedStatement myStmt = conn.prepareStatement(query);
		myStmt.setString(1, name);
		ResultSet rs = myStmt.executeQuery();
		while (rs.next()) {
			int eid = rs.getInt("id");
			String ename = rs.getString("name");
			String contact = rs.getString("contact");
			employee = new Employee();
			employee.setId(eid);
			employee.setName(ename);
			employee.setContact(contact);
		}
		rs.close();
		return employee;
	}
}