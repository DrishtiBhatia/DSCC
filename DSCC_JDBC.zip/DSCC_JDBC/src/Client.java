import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.*;

public class Client {

	Client() {
	}

	public static void main(String[] args) throws Exception {
		try {
			Registry registry = LocateRegistry.getRegistry(null);
			EmployeeInterface stub = (EmployeeInterface) registry.lookup("employee");
			Scanner sc = new Scanner(System.in);
			while (true) {
				System.out.print("Enter choice:\n1. Get All Employees\n2. Get Employee By Name ");
				int option = sc.nextInt();
				if (option == 1) {
					List<Employee> list = (List<Employee>) stub.getallemployees();
					for (Employee e : list) {
						System.out.println("ID: " + e.getId());
						System.out.println("Name:" + e.getName());
						System.out.println("Contact:" + e.getContact());
					}
				}
				if (option == 2) {
					System.out.print("Enter employee name: ");
					String name = sc.next();
					Employee employee = (Employee)stub.getcontactbyname(name);
					System.out.println("Contact: "+ employee.getContact());
				}
			}
		} catch (Exception e) {
			System.err.println("Client exception: " + e.toString());
			e.printStackTrace();
		}
	}
}
