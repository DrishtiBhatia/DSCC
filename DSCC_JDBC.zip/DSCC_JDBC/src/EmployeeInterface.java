import java.rmi.Remote;
import java.util.*;

public interface EmployeeInterface extends Remote {
	public List<Employee> getallemployees() throws Exception;
	public Employee getcontactbyname(String name) throws Exception;
}