import java.io.IOException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "HelloAppEngine", urlPatterns = { "/hello" })
public class HelloAppEngine extends HttpServlet {
	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
		response.setContentType("text/plain");
		response.setCharacterEncoding("UTF-8");
		 
		{
			

		//Sum of Even and odd numbers
//			int arr[] = { 2,4,8,19,29};
//			response.getWriter().print("Array : ");
//			for (int i = 0; i <arr.length; i++) {
//				response.getWriter().print(" " + arr[i]);}
//			int sumE=0,sumO=0;
//			for(int i = 0; i < arr.length; i++)
//	        {
//	            if(arr[i] % 2 == 0)
//	            {
//	                sumE = sumE + arr[i];
//	            }
//	            else
//	            {
//	                sumO = sumO + arr[i];
//	            }
//	        }
//			response.getWriter().print("Sum of Even Numbers:"+sumE);
//			response.getWriter().print("Sum of Odd Numbers:"+sumO);
//	    }
//	}
			
			
			
			
			//Show even odd numbers in array
//			int arr[] = { 2,4,8,19,29};
//			response.getWriter().print("Array : ");
//			for (int i = 0; i <arr.length; i++) {
//				response.getWriter().print(" " + arr[i]);}
//			
//			response.getWriter().println(" ");  
//			response.getWriter().println("Odd Numbers:");  
//			for(int i=0;i<arr.length;i++){  
//			if(arr[i]%2!=0){  
//			response.getWriter().print(arr[i] +" ");  
//			}  
//			}  
//			response.getWriter().println("Even Numbers:");  
//			for(int i=0;i<arr.length;i++){  
//			if(arr[i]%2==0){  
//			response.getWriter().print(arr[i] + " ");  
//			}
			
			
		//Sum of values of integer array	
		//int arr[] = { 2,4,8,19,29};
		//response.getWriter().print("Array : ");
		//for (int i = 0; i <arr.length; i++) {
			//response.getWriter().println(" " + arr[i]);}
//		int sum=0;
//		int i;
//		for (i = 0; i < arr.length; i++)
//	        sum += arr[i]; 
//		 
//		 
//		
//		   response.getWriter().println("Sum of given array is " + sum);
		
		//Binary Search
		//int arr[]={2,4,8,19,29};
		//int key = 19;
		//response.getWriter().print("Array : ");
		//for (int i = 0; i <arr.length; i++) {
			//response.getWriter().print(" " + arr[i]);
		//}
		//response.getWriter().println("\n\nSearch for element: " + key + "\n");
		//int last = arr.length-1;
		//int first = 0;
		//int mid = (first + last) / 2;
		//while (first <= last) {
		//	if (arr[mid] < key) {
			//	first = mid + 1;
			//} else if (arr[mid] == key) {
			//	response.getWriter().print("Element is found at index: " + mid + "\n");
			//	break;
			//} else {
			//	last = mid - 1;
			//}
			//mid = (first + last) / 2;
		//}
		//if (first > last) {
		//	response.getWriter().print("Element is not found!");
		//
			//Prime or Not
//			PrintWriter out = response.getWriter();
//			String num = request.getParameter("number");
//			int n = Integer.parseInt(num);
//			int i, m = 0, flag = 0;
//			m = n / 2;
//			if (n == 0 || n == 1) {
//	
//			out.println("<h1>"+n + " is not a Prime Number</h1>");
//			} else {
//			for (i = 2; i <= m; i++) {
//			if (n % i == 0) {
//			flag = 1;
//			break;
//			}
//			}
//			if (flag == 0) {
//			out.println("<h1>"+n + " is a Prime Number</h1>");
//			}
//			else {
//			out.println("<h1>"+n +" is not a Prime Number</h1>");
			}
			}
		}
}

 