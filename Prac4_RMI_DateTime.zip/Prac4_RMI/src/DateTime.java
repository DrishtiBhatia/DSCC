import java.rmi.*;

public interface DateTime extends Remote {
	public String date(int op) throws RemoteException;
}
