import java.rmi.Naming;

public class MyServer {
	public static void main(String args[]) {
		try {
			NoToWordsInterface stub = new NoToWordsRemote();
			Naming.rebind("rmi://localhost:5000/ashvita", stub);
			System.out.println("Number in words: ");
		} catch (Exception e) {
			System.out.print("exception on server");
			System.out.println(e);
		}
	}
}
