import java.rmi.Remote;
import java.rmi.RemoteException;

public interface NoToWordsInterface extends Remote {
	public void numberToWords(char num[]) throws RemoteException;
}
