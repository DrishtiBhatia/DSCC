import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.*;

public class Client {
	Client() {
	}

	public static void main(String[] args) throws Exception {
		try {
			Registry registry = LocateRegistry.getRegistry(null);
			BooksInterface stub = (BooksInterface) registry.lookup("book");
			Scanner sc = new Scanner(System.in);
			while (true) {
				System.out.print("Enter choice:\n1. Get All Books\n2. Get Book By Id ");
				int option = sc.nextInt();
				if (option == 1) {
					List<Book> list = (List<Book>) stub.getAllBooks();
					for (Book s : list) {
						System.out.println("ID: " + s.getBook_id());
						System.out.println("Name: " + s.getBook_name());
						System.out.println("Author: " + s.getBook_author());
					}
				}
				if (option == 2) {
					System.out.print("Enter book id: ");
					int id = sc.nextInt();
					Book book = (Book) stub.getBookById(id);
					System.out.println("ID: " + book.getBook_id() + "\nName: " + book.getBook_name() + "\nAuthor: "
							+ book.getBook_author() + "\n");

				}
			}
		} catch (Exception e) {
			System.err.println("Client exception: " + e.toString());
			e.printStackTrace();
		}
	}
}