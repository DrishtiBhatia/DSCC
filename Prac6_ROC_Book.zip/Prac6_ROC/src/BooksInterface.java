import java.rmi.Remote;
import java.util.*;

public interface BooksInterface extends Remote {
	public List<Book> getAllBooks() throws Exception;

	public Book getBookById(int id) throws Exception;
}