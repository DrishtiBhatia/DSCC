import java.rmi.*;

public interface EqIntf extends Remote {
	String Eq(int a, int b, int c) throws RemoteException;
}