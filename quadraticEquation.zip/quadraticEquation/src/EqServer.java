import java.net.*;
import java.rmi.*;

public class EqServer {
	public static void main(String args[]) {
		try {
			EqServerImpl esi = new EqServerImpl();
			Naming.rebind("EquationServer", esi);
			System.out.println("The server is started.");
		} catch (Exception e) {
		}
	}
}