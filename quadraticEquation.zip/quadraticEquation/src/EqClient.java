import java.rmi.*;
import java.io.*;

public class EqClient {
	public static void main(String args[]) {
		try {
			String equrl = "rmi://localhost/EquationServer";
			EqIntf eqin = (EqIntf) Naming.lookup(equrl);
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int a, b, c;
			System.out.print("\nEnter the value of a: ");
			a = Integer.parseInt(br.readLine());
			System.out.print("\nEnter the value of b: ");
			b = Integer.parseInt(br.readLine());
			System.out.print("\nEnter the value of c: ");
			c = Integer.parseInt(br.readLine());
			System.out.println("\n\nAnswer: " + eqin.Eq(a, b, c));
		} catch (Exception e) {
			System.out.println("Exception: " + e);
		}
	}
}